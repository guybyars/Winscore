// This header is NOT generated.

#ifndef _CkSettings_H
#define _CkSettings_H
#include "chilkatDefs.h"

#include "Chilkat_C.h"

CK_C_VISIBLE_PUBLIC void CkSettings_cleanupMemory(void);
CK_C_VISIBLE_PUBLIC void CkSettings_initializeMultithreaded(void);

#endif
